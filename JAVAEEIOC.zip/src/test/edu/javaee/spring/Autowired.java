package test.edu.javaee.spring;

public @interface Autowired {

}
